"""scripts package."""
